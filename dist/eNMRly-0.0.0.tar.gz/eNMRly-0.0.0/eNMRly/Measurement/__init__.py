__all__ = ['Pavel', 'Juergen1']
from .Pavel import Pavel
from .Juergen1 import Juergen1
print('Measurement Module imported')
